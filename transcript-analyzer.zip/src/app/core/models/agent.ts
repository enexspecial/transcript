export class Agent {
    agentID!: string;
    fullName!: string;
    email!: string;
}
