import { Routes } from '@angular/router';

import AnalyzerComponent from './analyzer.component';

export const ROUTES: Routes = [{
    path: '',
    component: AnalyzerComponent
}];
